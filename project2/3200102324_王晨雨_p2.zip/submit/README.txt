Server.java为这次工程的代码
server.jar为Server.java打包的jar包
您可以用client.jar客户端连接服务器，也可以用nc等方式连接
我设置的端口是8080（127.0.0.1）