report.pdf为本次project的报告
src文件夹中为本次工程的代码
在src目录下命令行输入java -Dfile.encoding=utf-8 -jar MiniCAD.jar运行我已经打包好的MiniCAD.jar运行程序
同时我上传了一个test文件，你可以运行程序后load这个test文件，就可以看到我之前画的图
详见报告中第一部分和第三部分