public enum FileOperationType {
    NONE, LOAD, SAVE;
}
