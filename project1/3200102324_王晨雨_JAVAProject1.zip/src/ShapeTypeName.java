public enum ShapeTypeName {
    NONE, LINE, RECTANGLE, CIRCLE, TEXT;
}
