public enum ResizeTypeName {
    NO, BIGGER, SMALLER;
}
