本目录下为hw2的代码以及可执行文件。
myBigIntCal.cpp及其exe文件为hw2-1
DH.cpp及其exe文件为hw2-2
直接按照hw2requirment文件里的输入输出格式输入即可。