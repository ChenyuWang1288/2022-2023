function [image_matrix] = ChangeToMat(image)
    resized_image = imresize(image, [512, 512]);
    
    % change the matix to mat
    image_matrix = double(resized_image); 

end

