function imdct = DCT(in)
    % Two-dimensional Discrete Cosine Transform (DCT2)
    block_size = 8;
    num_blocks = size(in, 1) / block_size;
    imdct = zeros(size(in));
    
    % Apply DCT2 to each block
    for l = 1:num_blocks
        for c = 1:num_blocks
            % Compute the indices for the current block
            row_indices = 1 + (l-1) * block_size : l * block_size;
            col_indices = 1 + (c-1) * block_size : c * block_size;
            % Extract the current block from the input matrix
            block = in(row_indices, col_indices);
            % Apply DCT2 to the current block and store the transformed coefficients
            imdct(row_indices, col_indices) = my_dct2(block);
        end
    end
end
