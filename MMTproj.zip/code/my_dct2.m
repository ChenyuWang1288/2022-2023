function dct_image = my_dct2(image)
    % Perform 2D Discrete Cosine Transform (DCT2) on the input image
    
    [M, N] = size(image);
    dct_image = zeros(M, N);
    
    % Iterate over each pixel in the DCT matrix
    for m = 1:M
        for n = 1:N
            sum = 0;
            
            % Iterate over each pixel in the input image
            for x = 1:M
                for y = 1:N
                    % Compute the DCT coefficient for the current pixel
                    alpha_m = sqrt(1 / M);
                    alpha_n = sqrt(1 / N);
                    dct_coef = alpha_m * alpha_n * cos(pi * (m - 1 + 0.5) * (x - 1) / M) * cos(pi * (n - 1 + 0.5) * (y - 1) / N);
                    
                    % Accumulate the sum by multiplying the input pixel with the DCT coefficient
                    sum = sum + image(x, y) * dct_coef;
                end
            end
            dct_image(m, n) = sum;
        end
    end
end
