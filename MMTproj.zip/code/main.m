clear; % Clear variables
clc; % Clear command window

%% Read input image and convert to matrix
input = imread("test3.jpg");
image_mat = ChangeToMat(input);
image = image_mat;
load("quant_matrix.mat"); % Load quantization matrix
figure1 = image;

%% Initialize variables
imdct = zeros(512, 512);
I = image - 128;
alpha = 5; 
quant = alpha * quant;
figure2 = I;

%% Apply DCT transform
imdct = DCT(I);
figure3 = imdct;

%% Quantization process
imquant = zeros(512, 512);
for l = 1:64
    for c = 1:64
        imquant(1+(l-1)*8:l*8,1+(c-1)*8:c*8) = round((imdct(1+(l-1)*8:l*8,1+(c-1)*8:c*8)) ./ quant);
    end
end
figure4 = imquant;

%% Decompression process
origin = zeros(512, 512);
for l = 1:64
    for c = 1:64
        origin(1+(l-1)*8:l*8,1+(c-1)*8:c*8) = idct2((imquant(1+(l-1)*8:l*8,1+(c-1)*8:c*8)) .* quant);
    end
end
origin = origin + 128;

%% Display results
figure;
subplot(2,3,1);
imshow(figure1, [0,255]);
xlabel("(a) 原始图像");
subplot(2,3,2);
imshow(figure2, [0,255]);
xlabel("(b) 转化为[-128,127]后的图像");
subplot(2,3,3);
imshow(figure3, [0,255]);
xlabel("(c) DCT变换后的图像");
subplot(2,3,4);
imshow(figure4, [0,255]);
xlabel("(d) 量化后的图像");
subplot(2,3,5);
imshow(origin, [0,255]);
xlabel("(e) 解压缩后的图像");