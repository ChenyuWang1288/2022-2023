打开MATLAB到当前目录，直接运行main.m文件，
我提供了三个测试图像test1.jpg，test2.jpg，test3.jpg，
report.pdf为本次实验的报告。